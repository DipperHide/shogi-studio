# Corresponding YaneuraOu V9.00 source

All upstream source files from the official V9.00 release are included unchanged.

Android: Install Python 3.11+ and the Android NDK 28.1.13356709, then run:

    python scripts/build_engine_android.py --ndk C:/path/to/android-ndk

This compiles an Android API 24 arm64 PIE executable, halfKP256 NNUE, using
the compiler flags recorded in the script. No evaluation data is needed to
compile. `nn.bin` is supplied separately for running the engine.

Windows process host: from Windows PowerShell with .NET Framework installed:

    ./scripts/build_engine_host.ps1

Windows engine: use the included upstream Makefile, NNUE halfKP256 edition,
SSE42 target and tournament build. Upstream toolchain/build instructions:
https://github.com/yaneurao/YaneuraOu/wiki/やねうら王のビルド手順

The Android Godot platform bridge is a separate app component, not a change
to the YaneuraOu source. Its full source is in the game's android-plugin folder.
